<?php
session_start();
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $otp = rand(100000, 999999); // Generate a 6-digit OTP
    $expiry = date('Y-m-d H:i:s', strtotime('+5 minutes')); // OTP valid for 5 minutes

    $sql = "INSERT INTO otp_requests (email, otp, expiry) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $email, $otp, $expiry);

    if ($stmt->execute()) {
        // Send OTP via email
        $to = $email;
        $subject = "Your OTP Code";
        $message = "Your OTP code is: $otp";
        $headers = "From: no-reply@yourdomain.com";

        if (mail($to, $subject, $message, $headers)) {
            echo "OTP sent successfully!";
        } else {
            echo "Failed to send OTP.";
        }
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
