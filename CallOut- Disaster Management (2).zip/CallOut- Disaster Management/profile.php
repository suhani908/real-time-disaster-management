<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_info = null;

// Prepare and execute the SQL statement
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_info = $result->fetch_assoc();
} else {
    echo "User not found.";
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" type="text/css" href="css/nav_bar.css"> <!-- Link to your main CSS file -->
    <link rel="stylesheet" type="text/css" href="css/profile.css"> <!-- Link to the new CSS file -->
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="navbar-content">
            <div class="navbar-left">
                <img src="images/logo.png" alt="Logo" class="logo">
            </div>
            <div class="navbar-center">
                <span id="current_time"><?php echo date('Y-m-d H:i:s'); ?></span>
            </div>
            <div class="navbar-right">
                <button class="menu-button" onclick="toggleMenu()">☰</button>
                <div id="menu" class="menu">
                    <a href="profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Profile Page Content -->
    <div class="profile-container">
        <div class="profile-header">
            <h1>My Profile</h1>
        </div>
        <div class="profile-info">
            <p><label for="username">Username:</label> <?php echo htmlspecialchars($user_info['username'] ?? ''); ?></p>
            <p><label for="email">Email:</label> <?php echo htmlspecialchars($user_info['email'] ?? ''); ?></p>
            <p><label for="name">Full Name:</label> <?php echo htmlspecialchars($user_info['full_name'] ?? ''); ?></p>
            <p><label for="phone">Phone:</label> <?php echo htmlspecialchars($user_info['phone'] ?? ''); ?></p>
            <p><label for="address">Address:</label> <?php echo htmlspecialchars($user_info['address'] ?? ''); ?></p>
            <p><label for="points">Reward Points:</label> <?php echo htmlspecialchars($user_info['points'] ?? '0'); ?></p>
        </div>
        <a href="update.php" class="update-button">Update Profile</a>
        <br><br>

        <!-- Go Back Link -->
        <a href="report.php" class="go-back-button">Go Back</a>
    </div>

    <script>
        // Function to show or hide the menu
        function toggleMenu() {
            const menu = document.getElementById('menu');
            menu.classList.toggle('show');
        }

        // Function to update current time every second
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleString('en-US', { hour12: true });
            document.getElementById('current_time').innerHTML = timeString;
        }

        // Update the time every second after the page loads
        window.onload = function() {
            setInterval(updateTime, 1000);
        };
    </script>
</body>
</html>
