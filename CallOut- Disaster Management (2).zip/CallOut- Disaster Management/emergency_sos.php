<?php
session_start();
include('db.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$submit_success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $disaster_type = $_POST['disaster_type'];
    $casualties = $_POST['casualties'];
    $injuries = $_POST['injuries'];
    $created_at = date('Y-m-d H:i:s');  // Current timestamp

    $photo_url = null;

    if (isset($_FILES['photo_file']) && $_FILES['photo_file']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . '/uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = basename($_FILES['photo_file']['name']);
        $target_file = $upload_dir . $file_name;

        if ($_FILES['photo_file']['size'] > 100 * 1024 * 1024) {
            echo "<script>alert('File size exceeds limit: $file_name');</script>";
        } else {
            if (move_uploaded_file($_FILES['photo_file']['tmp_name'], $target_file)) {
                $photo_url = $file_name;
            } else {
                echo "<script>alert('Failed to upload file: $file_name');</script>";
            }
        }
    }

    if (isset($_POST['photo_data'])) {
        $photo_data = $_POST['photo_data'];
        if (preg_match('/^data:image\/(jpeg|png);base64,/', $photo_data, $matches)) {
            $image_type = $matches[1];
            $photo_data = str_replace($matches[0], '', $photo_data);
            $photo_data = base64_decode($photo_data);

            $photo_file_name = uniqid() . '.' . $image_type;
            $photo_file_path = __DIR__ . '/uploads/' . $photo_file_name;

            if (file_put_contents($photo_file_path, $photo_data)) {
                $photo_url = $photo_file_name;
            } else {
                echo "<script>alert('Failed to save photo');</script>";
            }
        }
    }

    $sql = "INSERT INTO emergency_reports (disaster_type, casualties, injuries, photo_url, created_at) 
            VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $disaster_type, $casualties, $injuries, $photo_url, $created_at);

    if ($stmt->execute()) {
        $submit_success = true;
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emergency SOS</title>
    <link rel="stylesheet" type="text/css" href="css/sos.css">
    <style>
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
        .radio-group {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 10px 0;
        }
        .radio-group input {
            margin-right: 5px;
        }
        .popup {
            display: none;
            padding: 20px;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        #camera-container {
            display: none;
            position: relative;
        }
        #camera {
            width: 100%;
            height: auto;
        }
        #snapshot {
            display: none;
            width: 100%;
            height: auto;
        }
        #start-camera {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .button {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
        }
        .button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Emergency SOS Submission</h1>
        <form action="" method="post" enctype="multipart/form-data" id="sos-form">
            <label for="disaster-type">Disaster Type:</label>
            <select id="disaster-type" name="disaster_type" required>
                <option value="Earthquake">Earthquake</option>
                <option value="Cyclone">Cyclone</option>
                <option value="Thunderstorm">Thunderstorm</option>
            </select><br>

            <label>Casualties:</label>
            <div class="radio-group">
                <label><input type="radio" name="casualties" value="yes" required> Yes</label>
                <label><input type="radio" name="casualties" value="no" required> No</label>
            </div><br>

            <label>Injuries:</label>
            <div class="radio-group">
                <label><input type="radio" name="injuries" value="yes" required> Yes</label>
                <label><input type="radio" name="injuries" value="no" required> No</label>
            </div><br>

            <label for="photo-file">Upload a Photo:</label>
            <input type="file" id="photo-file" name="photo_file" accept="image/*"><br>

            <label for="photo-camera">Or capture a photo:</label>
            <button type="button" id="start-camera">Open Camera</button>
            <div id="camera-container">
                <video id="camera" autoplay></video>
                <canvas id="snapshot"></canvas>
                <button type="button" onclick="capturePhoto()">Capture Photo</button>
            </div>
            <input type="hidden" id="photo-data" name="photo_data">
            <br>
            <button type="submit">Submit SOS</button>
            <a href="report.php" class="button">Go Back</a> <!-- Go Back Button -->
        </form>

        <?php if ($submit_success): ?>
        <div id="popup" class="popup">SOS report submitted successfully!</div>
        <?php endif; ?>
    </div>

    <script>
    const startCameraButton = document.getElementById('start-camera');
    const cameraContainer = document.getElementById('camera-container');
    const video = document.getElementById('camera');
    const canvas = document.getElementById('snapshot');
    const photoDataInput = document.getElementById('photo-data');

    startCameraButton.addEventListener('click', function() {
        cameraContainer.style.display = 'block';
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
                video.srcObject = stream;
            })
            .catch(err => {
                console.error('Error accessing the camera: ', err);
                alert('Unable to access camera. Please check your device settings.');
            });
    });

    function capturePhoto() {
        const context = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        photoDataInput.value = dataUrl;
        cameraContainer.style.display = 'none';
        const stream = video.srcObject;
        const tracks = stream.getTracks();
        tracks.forEach(track => track.stop());
    }

    const popup = document.getElementById('popup');
    if (popup) {
        setTimeout(() => popup.style.display = 'none', 3000);
    }
    </script>

</body>
</html>
