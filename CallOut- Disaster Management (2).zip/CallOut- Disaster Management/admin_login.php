<!-- admin_login.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div class="header">
        <h1>Admin Login</h1>
    </div>
    <div class="container">
        <form action="admin_login_process.php" method="post">
            <label for="admin_username">Username:</label>
            <input type="text" id="admin_username" name="admin_username" required>
            
            <label for="admin_password">Password:</label>
            <input type="password" id="admin_password" name="admin_password" required>
            
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
