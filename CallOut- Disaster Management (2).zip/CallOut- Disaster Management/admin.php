<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="css/admin.css">
</head>
<body>
    <div class="header">
        <h1>Admin Dashboard</h1>
    </div>
    <div class="container">
        <h2>Emergency SOS Reports</h2>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Disaster Type</th>
                    <th>Casualties</th>
                    <th>Injuries</th>
                    <th>Media</th>
                    <th>Report Time</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include('db.php');

                // Fetching the SOS reports from the emergency_reports table
                $sos_sql = "SELECT * FROM emergency_reports";
                $sos_result = $conn->query($sos_sql);

                if ($sos_result->num_rows > 0) {
                    while ($sos_row = $sos_result->fetch_assoc()) {
                        // Handle media files (if any)
                        $media_files = [];
                        if (isset($sos_row['photo_url']) && !empty($sos_row['photo_url'])) {
                            $media_files[] = "<a href='uploads/{$sos_row['photo_url']}' target='_blank'>View Media</a>";
                        }
                        $media_links = implode(', ', $media_files);

                        // Format report_time to a readable format
                        $formatted_time = isset($sos_row['report_time']) ? date("F j, Y, g:i a", strtotime($sos_row['report_time'])) : 'N/A';

                        echo "<tr>
                                <td>" . (isset($sos_row['id']) ? $sos_row['id'] : 'N/A') . "</td>
                                <td>" . (isset($sos_row['user_id']) ? $sos_row['user_id'] : 'N/A') . "</td>
                                <td>" . (isset($sos_row['disaster_type']) ? $sos_row['disaster_type'] : 'N/A') . "</td>
                                <td>" . (isset($sos_row['casualties']) ? $sos_row['casualties'] : 'N/A') . "</td>
                                <td>" . (isset($sos_row['injuries']) ? $sos_row['injuries'] : 'N/A') . "</td>
                                <td>$media_links</td>
                                <td>$formatted_time</td>
                            </tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No Emergency SOS reports found</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <h2>Other Reported Disasters</h2>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Disaster Type</th>
                    <th>Status</th>
                    <th>Description</th>
                    <th>Location</th>
                    <th>Media</th>
                    <th>Report Time</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Fetching the disaster reports from the reports table
                $reports_sql = "SELECT * FROM reports";
                $reports_result = $conn->query($reports_sql);

                if ($reports_result->num_rows > 0) {
                    while ($reports_row = $reports_result->fetch_assoc()) {
                        // Handle media URLs (multiple columns)
                        $media_files = [];
                        if (isset($reports_row['imgage_video_url']) && !empty($reports_row['imgage_video_url'])) {
                            $media_files[] = "<a href='uploads/{$reports_row['imgage_video_url']}' target='_blank'>View File 1</a>";
                        }
                        if (isset($reports_row['image_video_url1']) && !empty($reports_row['image_video_url1'])) {
                            $media_files[] = "<a href='uploads/{$reports_row['image_video_url1']}' target='_blank'>View File 2</a>";
                        }
                        if (isset($reports_row['image_video_url2']) && !empty($reports_row['image_video_url2'])) {
                            $media_files[] = "<a href='uploads/{$reports_row['image_video_url2']}' target='_blank'>View File 3</a>";
                        }

                        // Join media file links
                        $media_links = implode(', ', $media_files);

                        // Format report_time to a readable format
                        $formatted_time = isset($reports_row['report_time']) ? date("F j, Y, g:i a", strtotime($reports_row['report_time'])) : 'N/A';

                        // Generate Google Maps link using the location description
                        $location_description = isset($reports_row['location']) ? urlencode($reports_row['location']) : '';
                        $location_link = $location_description ? "https://www.google.com/maps/search/?api=1&query={$location_description}" : '#';

                        echo "<tr>
                                <td>" . (isset($reports_row['id']) ? $reports_row['id'] : 'N/A') . "</td>
                                <td>" . (isset($reports_row['user_id']) ? $reports_row['user_id'] : 'N/A') . "</td>
                                <td>" . (isset($reports_row['disaster_type']) ? $reports_row['disaster_type'] : 'N/A') . "</td>
                                <td>" . (isset($reports_row['disaster_status']) ? $reports_row['disaster_status'] : 'N/A') . "</td>
                                <td>" . (isset($reports_row['disaster_description']) ? $reports_row['disaster_description'] : 'N/A') . "</td>
                                <td><a href='$location_link' target='_blank'>" . (isset($reports_row['location']) ? $reports_row['location'] : 'N/A') . "</a></td>
                                <td>$media_links</td>
                                <td>$formatted_time</td>
                            </tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No reports found</td></tr>";
                }

                // Close the database connection
                $conn->close();
                ?>
            </tbody>
        </table>

        <a href="logout.php">Logout</a>
    </div>
</body>
</html>
