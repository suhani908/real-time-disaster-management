<?php
// replace 'your_password_here' with the password you want to hash
$password = 'admin123';

// Generate a hashed password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

echo $hashed_password;
?>
