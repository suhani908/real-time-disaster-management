<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// Fetch username from session
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Disaster Report</title>
</head>
<body>
    <h1>Submit Disaster Report</h1>
    <h2>Hello, <?php echo htmlspecialchars($username); ?>!</h2> <!-- Display the username -->

    <form action="" method="post" enctype="multipart/form-data">
        <!-- Form content -->
    </form>

    <a href="logout.php">Logout</a>
</body>
</html>
