<?php
session_start();
include('db.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$report_success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $disaster_type = $_POST['disaster_type'];
    $disaster_status = $_POST['disaster_status'];
    $disaster_description = $_POST['disaster_description'];
    $location = $_POST['location'];
    $other_disaster = isset($_POST['other_disaster']) ? $_POST['other_disaster'] : null;

    if ($disaster_type == 'others' && !empty($other_disaster)) {
        $disaster_type = "others(" . $other_disaster . ")";
    }

    $upload_dir = __DIR__ . '/uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $media_urls = [];
    foreach ($_FILES['media']['tmp_name'] as $key => $tmp_name) {
        $file_name = basename($_FILES['media']['name'][$key]);
        $target_file = $upload_dir . $file_name;

        if ($_FILES['media']['size'][$key] > 100 * 1024 * 1024) {
            echo "<script>alert('File size exceeds limit: $file_name');</script>";
            continue;
        }

        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'avi', 'webp'];
        if (!in_array($file_type, $allowed_types)) {
            echo "<script>alert('File type not allowed: $file_name');</script>";
            continue;
        }

        if (move_uploaded_file($tmp_name, $target_file)) {
            $media_urls[] = $file_name;
        } else {
            echo "<script>alert('Failed to upload file: $file_name');</script>";
        }
    }

    $imgage_video_url = isset($media_urls[0]) ? $media_urls[0] : null;
    $image_video_url1 = isset($media_urls[1]) ? $media_urls[1] : null;
    $image_video_url2 = isset($media_urls[2]) ? $media_urls[2] : null;

    $sql = "INSERT INTO reports (user_id, disaster_type, disaster_status, disaster_description, location, imgage_video_url, image_video_url1, image_video_url2) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssssss", $user_id, $disaster_type, $disaster_status, $disaster_description, $location, $imgage_video_url, $image_video_url1, $image_video_url2);

    if ($stmt->execute()) {
        $report_success = true;
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disaster Report Submission</title>
    <link rel="stylesheet" type="text/css" href="css/nav_bar.css">
    <link rel="stylesheet" type="text/css" href="css/report.css">
    <style>
        .popup {
            display: none;
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        .popup.show {
            display: block;
        }
        #emergency-sos-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #f44336;
            color: white;
            border: none;
            padding: 15px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            z-index: 1000;
        }
        #emergency-sos-button:hover {
            background-color: #d32f2f;
        }
        .container {
            margin-bottom: 80px; /* To ensure space for the SOS button */
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <div class="navbar-left">
                <img src="images/logo.png" alt="Logo" class="logo">
            </div>
            <div class="navbar-center">
                <span id="current_time"></span>
            </div>
            <div class="navbar-right">
                <button class="menu-button" onclick="toggleMenu()">☰</button>
                <div id="menu" class="menu">
                    <a href="profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="marquee">
        <div class="marquee-content">
            WELCOME TO DISASTER MANAGEMENT PORTAL! Please ensure you have filled the data correctly.
        </div>
    </div>

    <div class="report-heading-section">
        <h1>Submit Disaster Report</h1>
    </div>

    <div class="container">
        <form action="" method="post" enctype="multipart/form-data">
            <label for="disaster-type">Choose a Disaster Category:</label>
            <select id="disaster-type" name="disaster_type" onchange="toggleOtherDisaster()" required>
                <optgroup label="Natural Disasters">
                    <optgroup label="Geological Disasters">
                        <option>Earthquake</option>
                        <option>Tsunami</option>
                        <option>Volcanic Eruption</option>
                        <option>Landslide</option>
                        <option>Avalanche</option>
                    </optgroup>
                    <optgroup label="Hydrological Disasters">
                        <option>Flood</option>
                        <option>Flash Flood</option>
                        <option>Coastal Flooding</option>
                    </optgroup>
                    <optgroup label="Meteorological Disasters">
                        <option>Hurricane/Cyclone/Typhoon</option>
                        <option>Tornado</option>
                        <option>Blizzard</option>
                        <option>Hailstorm</option>
                        <option>Heatwave</option>
                        <option>Drought</option>
                    </optgroup>
                    <optgroup label="Climatological Disasters">
                        <option>Wildfire</option>
                        <option>Extreme Cold Wave</option>
                        <option>Extreme Heat Wave</option>
                    </optgroup>
                    <optgroup label="Biological Disasters">
                        <option>Epidemic</option>
                        <option>Pandemic</option>
                        <option>Insect Infestation</option>
                    </optgroup>
                    <optgroup label="Extraterrestrial Disasters">
                        <option>Meteorite Impact</option>
                        <option>Solar Flare</option>
                    </optgroup>
                </optgroup>
                <optgroup label="Man-Made Disasters">
                    <optgroup label="Technological Disasters">
                        <option>Industrial Accident</option>
                        <option>Chemical Spill</option>
                        <option>Nuclear Accident</option>
                        <option>Oil Spill</option>
                    </optgroup>
                    <optgroup label="Environmental Degradation">
                        <option>Deforestation</option>
                        <option>Pollution</option>
                    </optgroup>
                    <optgroup label="Conflict and War">
                        <option>Armed Conflict</option>
                        <option>Terrorist Attack</option>
                        <option>Bombing</option>
                    </optgroup>
                    <optgroup label="Transportation Disasters">
                        <option>Airplane Crash</option>
                        <option>Train Derailment</option>
                        <option>Shipwreck</option>
                        <option>Road Accidents</option>
                    </optgroup>
                    <option value="others">Others</option>
                </optgroup>
            </select><br>

            <label for="other_disaster" id="other_disaster_label" style="display: none;">Specify Other Disaster:</label>
            <input type="text" id="other_disaster" name="other_disaster" style="display: none;" placeholder="Specify if selected 'Others'">

            <label for="disaster-status">Disaster Status:</label>
            <select id="disaster-status" name="disaster_status" required>
                <option value="mild">Mild</option>
                <option value="severe">Severe</option>
                <option value="extreme">Extreme</option>
            </select><br>

            <label for="disaster-description">Disaster Description:</label><br>
            <textarea id="disaster-description" name="disaster_description" rows="4" cols="50" required></textarea><br>

            <label for="location">Disaster Location:</label>
            <input type="text" id="location" name="location" placeholder="Enter location" required><br>
            <button type="button" onclick="openMap()">View on Map</button><br>

            <label for="media">Upload Images/Videos (max 3 files):</label>
            <input type="file" id="media" name="media[]" multiple required><br>

            <input type="submit" value="Submit Report">
        </form>

        <?php if ($report_success): ?>
            <div class="popup show">
                <h2>Report Submitted Successfully!</h2>
                <p>Your report has been submitted. Thank you for your contribution.</p>
            </div>
        <?php endif; ?>
    </div>

    <button id="emergency-sos-button" onclick="window.location.href='emergency_sos.php'">Emergency SOS</button>

    <script>
        function updateClock() {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            const currentTime = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${hours}:${minutes}:${seconds}`;
            document.getElementById('current_time').textContent = currentTime;
        }

        setInterval(updateClock, 1000); // Update every second
        updateClock(); // Initial call to display time immediately when page loads

        function toggleOtherDisaster() {
            var disasterType = document.getElementById('disaster-type').value;
            var otherDisasterField = document.getElementById('other_disaster');
            var otherDisasterLabel = document.getElementById('other_disaster_label');

            if (disasterType === 'others') {
                otherDisasterField.style.display = 'block';
                otherDisasterLabel.style.display = 'block';
            } else {
                otherDisasterField.style.display = 'none';
                otherDisasterLabel.style.display = 'none';
            }
        }

        function toggleMenu() {
            var menu = document.getElementById('menu');
            menu.classList.toggle('show');
        }

        function openMap() {
            const location = document.getElementById('location').value;
            if (location) {
                window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`, '_blank');
            } else {
                alert('Please enter a location.');
            }
        }
    </script>
</body>
</html>
