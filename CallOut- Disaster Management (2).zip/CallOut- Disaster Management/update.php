<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_info = null;

// Fetch user information
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_info = $result->fetch_assoc();
} else {
    echo "User not found.";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    // Update user information
    $sql = "UPDATE users SET username = ?, email = ?, full_name = ?, phone = ?, address = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $username, $email, $full_name, $phone, $address, $user_id);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header('Location: report.php'); // Redirect to index.php
        exit();
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link rel="stylesheet" type="text/css" href="css/nav_bar.css"> <!-- Link to your main CSS file -->
    <link rel="stylesheet" type="text/css" href="css/update.css"> <!-- Link to the new CSS file -->
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="navbar-content">
            <div class="navbar-left">
                <img src="images/logo.png" alt="Logo" class="logo">
            </div>
            <div class="navbar-center">
                <span id="current_time"><?php echo date('Y-m-d H:i:s'); ?></span>
            </div>
            <div class="navbar-right">
                <button class="menu-button" onclick="toggleMenu()">☰</button>
                <div id="menu" class="menu">
                    <a href="profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Update Profile Page Content -->
    <div class="update-container">
        <h1>Update Profile</h1>
        <form action="" method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user_info['username'] ?? ''); ?>" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_info['email'] ?? ''); ?>" required><br>

            <label for="full_name">Full Name:</label>
            <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user_info['full_name'] ?? ''); ?>"><br>

            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($user_info['phone'] ?? ''); ?>"><br>

            <label for="address">Address:</label>
            <textarea id="address" name="address" rows="4" cols="50"><?php echo htmlspecialchars($user_info['address'] ?? ''); ?></textarea><br>

            <button type="submit">Update Profile</button>
        </form>
    </div>

    <script>
        // Function to show or hide the menu
        function toggleMenu() {
            const menu = document.getElementById('menu');
            menu.classList.toggle('show');
        }

        // Function to update current time every second
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleString('en-US', { hour12: true });
            document.getElementById('current_time').innerHTML = timeString;
        }

        // Update the time every second after the page loads
        window.onload = function() {
            setInterval(updateTime, 1000);
        };
    </script>
</body>
</html>
