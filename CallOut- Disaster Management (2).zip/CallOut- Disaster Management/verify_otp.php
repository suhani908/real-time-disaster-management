<?php
session_start();
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_otp = $_POST['otp'];
    $email = $_POST['email']; // Add email input to match OTP with email

    $sql = "SELECT otp, expiry FROM otp_requests WHERE email = ? AND otp = ? AND expiry > NOW()";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $input_otp);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "OTP verified successfully!";
        // Clear OTP from database
        $sql = "DELETE FROM otp_requests WHERE email = ? AND otp = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $input_otp);
        $stmt->execute();
    } else {
        echo "Invalid OTP or OTP has expired.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <h1>Verify OTP</h1>
    <form action="" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        
        <label for="otp">Enter OTP:</label>
        <input type="text" id="otp" name="otp" required>
        
        <button type="submit">Verify OTP</button>
    </form>
</body>
</html>
