<?php
$servername = "localhost";
$username = "root";
$password = "sql70772";  // Ensure this is correct
$dbname = "disaster_management";

$conn = new mysqli($servername, $username, $password, $dbname);
?>